#!/usr/bin/env python3
"""Mix a user-approved 14s Hindi narration into the V6 54s showcase.

Does not create or endorse a voice, revalidate live prices, or publish anything.
Only use on a newly rendered, fully verified 54s campaign, not the historical V6 master.
"""
import argparse, json, subprocess
from pathlib import Path


def probe(path):
    raw=subprocess.check_output(['ffprobe','-v','error','-show_entries',
      'format=duration:stream=codec_type,codec_name,width,height', '-of','json',str(path)],text=True)
    return json.loads(raw)


def mix(video,voice,output):
    video,voice,output=map(Path,(video,voice,output))
    for p in (video,voice):
        if not p.is_file():raise ValueError('Missing required video/voice file: '+str(p))
    vm=probe(video);am=probe(voice)
    vd=float(vm['format']['duration']);ad=float(am['format']['duration'])
    if not 53.8<=vd<=54.2:raise ValueError('Expected 54 second newly rendered V6 campaign')
    if not 9<=ad<=14:raise ValueError('Hindi product audio must cover 9-14 seconds of scene 32-46')
    videos=[x for x in vm['streams'] if x.get('codec_type')=='video']
    if not videos or (videos[0].get('width'),videos[0].get('height'))!=(720,1280):
        raise ValueError('Expected 720x1280 vertical MP4')
    output.parent.mkdir(parents=True,exist_ok=True)
    # Duck original ambient audio only under product showcase. Keep original story audio.
    graph=("[0:a]aresample=48000,volume='if(between(t,31.95,46.05),0.24,1)':eval=frame[bg];"
       "[1:a]aresample=48000,atrim=0:14,asetpts=PTS-STARTPTS,"
       "afade=t=in:st=0:d=0.18,afade=t=out:st=13.72:d=0.20,"
       "adelay=32000:all=1,volume=1.45[vo];"
       "[bg][vo]amix=inputs=2:duration=first:normalize=0,"
       "loudnorm=I=-16:LRA=9:TP=-1.5,atrim=0:54[outa]")
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(voice),
        '-filter_complex',graph,'-map','0:v:0','-map','[outa]','-c:v','copy',
        '-c:a','aac','-ar','48000','-b:a','192k','-movflags','+faststart','-t','54',str(output)]
    subprocess.run(cmd,check=True)
    res=probe(output)
    if abs(float(res['format']['duration'])-54)>0.2:raise RuntimeError('Audio mix duration drift')
    print('AUDIO_MASTERING_COMPLETE=YES')
    print('DYNAMIC_PRICE_QA_NOT_DONE_BY_THIS_TOOL=YES')
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--video',required=True)
    p.add_argument('--hindi-voice',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();mix(a.video,a.hindi_voice,a.output)
