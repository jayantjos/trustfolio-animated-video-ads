#!/usr/bin/env python3
import json,hashlib,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parents[1]
data=json.loads((root/'config/source_inventory.json').read_text())
for item in data['assets']:
 p=root/item['video'];digest=hashlib.sha256(p.read_bytes()).hexdigest();print(item['name'],'PASS' if digest==item['sha256'] else 'FAIL',item['duration_s'],'seconds')
