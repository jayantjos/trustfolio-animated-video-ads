#!/usr/bin/env python3
"""Fail-closed data validator. Render engine, voice cloning and lip-sync are NOT bundled."""
import json,sys
from pathlib import Path
x=json.loads(Path(sys.argv[1]).read_text());p=x['product'];price=p.get('price_inr')
assert isinstance(price,(int,float)) and price>0,'Verified numeric live price required'
assert price<=x['budget_inr'],'Exceeds selected budget'
assert len(p.get('specifications',[]))==4 and all(z.get('label') and z.get('value') and z['value']!='API_VALUE' for z in p['specifications']),'Four actual specs required'
assert p.get('name') and not p['name'].startswith('REPLACE_'),'Actual product name required'
assert Path(p['image_path']).is_file(),'Local product image required'
print('PRODUCT_CONTRACT_PASS')
