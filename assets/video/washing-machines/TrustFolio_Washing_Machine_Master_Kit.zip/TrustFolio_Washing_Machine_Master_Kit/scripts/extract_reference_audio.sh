#!/usr/bin/env bash
set -euo pipefail
# Usage: bash scripts/extract_reference_audio.sh input.mp4 output.wav
ffmpeg -nostdin -y -i "$1" -vn -ac 1 -ar 24000 -c:a pcm_s16le "$2"
